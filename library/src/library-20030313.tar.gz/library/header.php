<?php

//----------------------------------------------
//
//  Uncomment the header you wish to use,
//  Do the same in footer.php
//
//----------------------------------------------

// Original look, classic minimalist text
// mode interface.  Works great with lynx and
// those with slow connections!
//	include("templates/original/header.php");


// Blue, this is a very graphical dark blue
// theme.  Nice looking though.
	include("templates/blue/header.php");

?>
