<?php

//----------------------------------------------
//
//  Uncomment the footer you wish to use,
//  Do the same in header.php
//
//----------------------------------------------

// Original look
//	include("templates/original/footer.php");


// Blue
	include("templates/blue/footer.php");

?>
