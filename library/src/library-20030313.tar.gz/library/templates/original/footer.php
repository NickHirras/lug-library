<?php

echo "<br clear=both><hr size=1 color=#aaaacc>";
echo "<address><center><font size=-1>";
echo "Copyright &copy; 2003 by <a href=mailto:imnes@go.com>Nicholas
      Smith</a> and <a href=http://www.pcolalug.org>The Pensacola
      Linux Users Group</a>.<br>All Rights are Reserved.";
echo "</font></center></address>";
echo "</body>";
echo "</html>";
?>
