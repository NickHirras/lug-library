<?php
/*****************************************************************************
 *
 *	This is the master include file for the library application.
 *	Global variables and configuration info should be stored here.
 *	
 *	Created 03/03/2003 by Nicholas Smith (imnes@go.com)
 *	Copyright (C) 2003 Nicholas Smith & The Pensacola Linux Users Group
 *
 ****************************************************************************/

// Information for connecting to mysql.
$db_host 	= 'localhost';
$db_user 	= 'username';
$db_pass	= 'password';
$db_name	= 'databasename';


?>
